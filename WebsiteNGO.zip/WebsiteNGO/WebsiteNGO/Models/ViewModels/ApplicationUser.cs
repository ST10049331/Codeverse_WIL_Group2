﻿using Microsoft.AspNetCore.Identity;

namespace WebsiteNGO.Models.ViewModels
{
    public class ApplicationUser:IdentityUser
    {
        public string Email { get; set; }
        public string Password {  get; set; }
    }
}
