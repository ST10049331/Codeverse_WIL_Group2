﻿using System.ComponentModel.DataAnnotations;

namespace WebsiteNGO.Models
{
    public class Donations
    {
        [Required]
        [Key]
        public int DonationId { get; set; }
        public int DonorID { get; set; }
        public decimal Amount { get; set; }

        public DateTime DonationDate { get; set; }

    }
}
