﻿using System.ComponentModel.DataAnnotations;

namespace WebsiteNGO.Models
{
    public class Volunteers
    {
        [Required]
        [Key]
        public int voulunteerId { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }

    }
}
