﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using WebsiteNGO.Models;

namespace WebsiteNGO.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Donations> Donation { get; set; }
        public DbSet<Donors> Donor { get; set; }

        public DbSet<Events> Event { get; set; }

        public DbSet<Volunteers> Volunteer { get; set; }
    }
}
