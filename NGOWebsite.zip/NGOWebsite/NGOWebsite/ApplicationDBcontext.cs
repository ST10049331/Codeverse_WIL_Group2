﻿using Microsoft.EntityFrameworkCore;
using NGOWebsite.Models;

namespace NGOWebsite
{
    public class ApplicationDBcontext:DbContext

    {

        public ApplicationDBcontext(DbContextOptions options):base (options)
        { 
        
        }

        public DbSet<Donation> Donations { get; set; }
        public DbSet<Donor> Donors { get; set; }

        public DbSet<Events> Event { get; set; }

        public DbSet<Volunteer>volunteers { get; set; }

    }


}
