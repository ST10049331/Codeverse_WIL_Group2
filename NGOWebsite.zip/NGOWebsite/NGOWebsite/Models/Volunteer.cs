﻿using System.ComponentModel.DataAnnotations;

namespace NGOWebsite.Models
{
    public class Volunteer
    {
        [Required]
        [Key]
        public int voulunteerId { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }


    }
}
