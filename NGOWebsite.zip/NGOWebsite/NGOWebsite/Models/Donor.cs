﻿using System.ComponentModel.DataAnnotations;

namespace NGOWebsite.Models
{
    public class Donor
    {
        [Required]
        [Key]
        public int DonorId { get; set; }

        public string Name { get; set; }

        public string Email { get; set; }
    }
}
